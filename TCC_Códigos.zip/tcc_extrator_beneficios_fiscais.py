import PyPDF2
import re
import pandas as pd


files = []


for file in files:
    name = re.search(r'in-(\d{3,4})-(\d{4})\.pdf', str(file))


def ext_pdf(p,IN,DESC):
    page = reader.getPage(p)
    a = page.extractText()
    a = a.replace('\n','')
    b = re.split("(\d+\.)\s",a)
    cnpjs = re.findall("[0-9]{2}.[0-9]{3}.[0-9]{3}\/[0-9]{4}\-[0-9]{2}",a)
    for cnpj in cnpjs:
        for i in b:
            if cnpj in i:
                t = str(cnpj).replace('.','').replace('-','').replace('/','')+"\t"+str(DESC)
                rol.append(t)
    return(rol)

rol_in = {'RELAÇÃO DAS PJs - Matérias-primas, produtos intermediários e materiais de embalagem - até 05-03-2021':'IN 595-2005 Matérias-primas e embalagem',
          'RELAÇÃO DAS PJs - Importação de embalagens - até 15-10-2019':'IN 604-2006 Importação de Embalagens',
          'RELAÇÃO DAS PJs - Recap - até 05-03-2021':'IN 605-2006 Recap',
          'RELAÇÃO DAS PJs - Repes - até 05-03-2021':'IN 630-2006 Repes',
          'RELAÇÃO DAS PJs - Máquinas utilizadas na fabricação de papéis - até 05-03-2021':'IN 675-2006 Máquina para Fabricação de Papel',
          'RELAÇÃO DAS PJs - Reidi - até 05-03-2021':'IN 758-2007 Reidi',
          'RELAÇÃO DAS PJs - Remicex - até 05-03-2021':'IN 773-2007 Remicex',
          'RELAÇÃO DAS PJs - Navegação de cabotagem - até 05-03-2021':'IN 882-2008 Navegação de Cabotagem',
          'RELAÇÃO DAS PJs - Reporto - até 05-03-2021':'IN 1370-2013 Reporto'}

rol = []
for i in rol_in:
    IN = i
    DESC = rol_in[i]
    name_file = str(i).lower()+'.pdf'
    file = open(name_file,'rb')
    reader = PyPDF2.PdfFileReader(file)
    n_pages = reader.getNumPages()
    for p in range(n_pages):
        ext_pdf(p,IN,DESC)

df = pd.DataFrame(rol)
df = df.drop_duplicates(subset=None, keep='first', inplace=False)
df.to_csv('tcc_2_regimes_especiais.csv', sep='~', header=None, index=None)
