import requests
import os

def download_file(cnpj,operacao):
    url_1 = 'https://www.bndes.gov.br/SiteBNDES/bndes/bndes_pt/Galerias/Convivencia/Consuta_operacoes/operacoes_unificadas.csv?cpfcnpj='
    url_2 = '&operacao='
    url_3 = '&p_contrato=contrato'
    url = url_1+cnpj+url_2+operacao+url_3
    filename = cnpj + '.csv'
    try:
        r = requests.get(url, stream=True, timeout=100)
        with open(filename, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024): 
                if chunk:
                    f.write(chunk)
    except requests.exceptions.ConnectionError as e:
        print(str(e))
    return filename

operacoes = ['operacao_direta'],
             'operacao_indireta','operacao_renda_variavel','operacao_pre_embarque','operacao_pos_embarque']

file_names = {'operacao_direta':'bndes_op_direta.csv'},
              'operacao_indireta':'bndes_op_indiretas.csv',
              'operacao_renda_variavel':'bndes_op_rendavariavel.csv',
              'operacao_pre_embarque':'bndes_op_preembarque.csv',
              'operacao_pos_embarque':'bndes_op_posembarque.csv'}

for operacao in operacoes:
    file = open('cnpj_tcc.TXT', 'r')
    filenames = []
    for line in file:
        download_file(str(line[:14]),operacao)
        file_name = str(line[:14])+'.csv'
        filenames.append(file_name)
    final_file = str(file_names[operacao])
    base_file = 'base_'+operacao+'.csv'
    with open(final_file, 'w') as outfile:
        with open(base_file) as f:
            file_lines = f.readlines()
            outfile.writelines(max(file_lines))
        for fname in filenames:
            with open(fname) as infile:
                outfile.writelines(infile.readlines()[11:])
            os.remove(fname)
    print("Extração {} ok!!!".format(operacao))
